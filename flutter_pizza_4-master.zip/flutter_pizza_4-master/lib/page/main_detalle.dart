// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';

class MyDetalle extends StatefulWidget {
  List<String> chekersIngredient;
  String controlerNombre;
  String controlerApellido;
  String controlerTelefono;
  int size;
  MyDetalle(
      {required this.chekersIngredient,
      required this.size,
      required this.controlerNombre,
      required this.controlerApellido,
      required this.controlerTelefono,
      Key? key})
      : super(key: key);

  @override
  State<MyDetalle> createState() => _MyDetalleState();
}

class _MyDetalleState extends State<MyDetalle> {
  String body = '';
  String tamano = '';
  @override
  void initState() {
    super.initState();
    convertSize(valor: widget.size);
    body =
        'Cliente: ${widget.controlerNombre + ' ' + widget.controlerApellido}\nTelefono: ${widget.controlerTelefono}\nOrdeno: Un Pizza $tamano de ${widget.chekersIngredient.join(',')}';
  }

  convertSize({required int valor}) {
    switch (valor) {
      case 0:
        tamano = 'Small';
        break;
      case 1:
        tamano = 'Medium';
        break;
      case 2:
        tamano = 'Large';
        break;
      case 3:
        tamano = 'Extra';
        break;
      default:
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Detalle compra',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Detalle'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        body: Container(
          decoration: const BoxDecoration(
            //color: Colors.cyan,
            shape: BoxShape.circle,
            image: DecorationImage(
              image: NetworkImage(
                //'http://parmesanapizza.pyplabs.com/wp-content/uploads/sites/71/2020/02/parmesana_logoretina1.png',
                'https://static-images.ifood.com.br/image/upload/t_high/logosgde/a3beff65-67a5-4ef2-8060-5951b9ae28b5_RUTA6601.jpg',
              ),
            ),
          ),
          margin: const EdgeInsets.only(top: 6, left: 16, right: 16),
          child: Column(
            children: [
              Text(
                'Gracias por la Compra',
                style: styleT,
              ),
              Divider(),
              SizedBox(
                child: Text(
                  body,
                  style: styleT.copyWith(fontSize: 18),
                  maxLines: 8,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  TextStyle styleT = const TextStyle(fontSize: 24);
}
